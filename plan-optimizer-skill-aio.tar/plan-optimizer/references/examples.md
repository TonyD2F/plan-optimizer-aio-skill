---
description: "Example inputs and optimized outputs for plan-optimizer"
---

# Examples

## Example 1 — Vague idea → Optimized plan

**Input**: "We should add AI to the app so users can do more stuff."

**Optimized output excerpt**:
```markdown
## Optimized Plan: AI Assist for Core Workflows

### Goal
Let users complete the top 3 repeated tasks (search, summarize, draft) 50% faster via an in-app AI assistant.

### Success criteria
- Users can invoke AI from the main search bar and task list
- Median time-to-complete for the three tasks drops ≥50% in A/B test
- Error rate on AI-generated content stays below 5%

### Approach
Inline assistant with tool use (search existing data + generate) rather than a separate chat surface.

### Steps
1. Instrument current task completion times
2. Implement assistant with read-only tools first
3. Add generation with confirmation gate
4. Ship behind feature flag and measure

### Constraints / Non-goals
- Do not replace existing UI flows
- No autonomous actions without user confirmation
- Out of scope: voice, multi-agent orchestration

### Verification
A/B test on time-to-complete + qualitative error review on 50 samples
```

## Example 2 — Agent prompt improvement

**Input**: "You are a helpful coding agent. Write good code."

**Optimized excerpt**:
```markdown
You are a coding agent specialized in TypeScript backend services.

When given a task:
1. Restate the goal and success criteria in one sentence.
2. Identify the files and seams you will change.
3. Write or update tests first (RED).
4. Implement the minimum change that makes tests pass (GREEN).
5. Run the project's test and lint commands and paste the output.

Constraints:
- Do not add new dependencies without explicit approval.
- Prefer existing patterns in the codebase.
- Stop and ask if the change requires a database migration or irreversible action.

Done when: tests pass, lint is clean, and you have shown the relevant diff.
```
