---
description: "Scoring rubric and framework selection guidance for plan-optimizer"
---

# Scoring and Framework Selection

## Scoring Rubric

Apply consistently:

| Band | Meaning |
|------|---------|
| 1–3 | Absent or actively harmful. Executor must guess everything. |
| 4–6 | Present but underspecified. Will fill gaps with unstated assumptions. |
| 7–8 | Solid. Good enough to execute; refinement is marginal. |
| 9–10 | Complete and unambiguous. Nothing left to infer. |

## Framework / Approach Mapping

| Input type | Preferred structure | Key elements to force |
|------------|---------------------|-----------------------|
| Prompt (one-shot) | CO-STAR or RTF | Role, Task, Context, Output format, Constraints |
| Agent system prompt | Heuristics + tool guidance | Role, thinking process, tool selection rules, stopping conditions, irreversibility gates |
| Feature / product plan | Goal → Success criteria → Approach → Steps → Verification | Non-goals, edge cases, acceptance tests |
| Research idea | Hypothesis → Method → MVE → Success/failure criteria | Prior work awareness, risk, compute estimate |
| Business / strategy | Objective → Key results → Approach → Risks | Measurable outcomes, constraints, decision gates |
| Multi-step process | RISEN-style | Role, Instructions, Steps, End goal, Narrowing / out-of-scope |

When combining, use at most two frameworks. State which owns which phase.

## Clarification Question Priorities

Ask in this order until the biggest open branch is closed:

1. Success criteria (what "done" looks like)
2. Constraints and non-goals
3. Audience / user / consumer of the result
4. Key risks or irreversible actions
5. Verification method
