---
description: "Adversarial audit checklist for plans, ideas, and prompts"
---

# Adversarial Audit Checklist

Use this when stress-testing the chosen approach. Produce findings only for real risks.

## Failure Modes to Check

| Category | Look for | Why it breaks execution |
|----------|----------|-------------------------|
| Ambiguity | Vague words ("fast", "robust", "good", "user-friendly") without metrics | Agent or human will invent the definition |
| Contradictions | Conflicting requirements or success criteria | Executor picks one and ignores the other |
| Untestable criteria | "Works well", "feels right", no verification step | Cannot know when done or if correct |
| Missing edges | No handling of empty, error, concurrent, or boundary cases | Fails in production on first real use |
| Scope creep | Multiple unrelated outcomes in one plan | Partial completion reported as done |
| Assumption risk | Unstated dependency on data, tools, permissions, or external systems | Blocks or produces wrong result |
| Irreversibility | Delete, publish, send, charge, or mutate without confirmation | Hard to undo |
| Missing stop | No condition for "good enough" or max attempts | Infinite loop or excessive work |
| Ownership gap | Who decides / who implements / who verifies is unclear | Handoff fails |

## Finding Format

```markdown
### [Severity: High/Medium/Low] Finding ID — Short title
- **Evidence**: quote or paraphrase from the input
- **Why it breaks**: one sentence
- **Recommended patch**: concrete text or rule to add
- **Verification**: how to confirm the patch worked
```

Severity guide:
- **High** — will cause wrong implementation or false completion
- **Medium** — likely to cause rework or suboptimal result
- **Low** — polish or minor clarity issue
