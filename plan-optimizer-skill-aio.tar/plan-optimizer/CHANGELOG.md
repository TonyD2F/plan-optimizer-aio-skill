# Changelog

## 2026-10-22
- Initial skill creation
- Combined practices from Prompt Architect, grill-me, Superpowers brainstorming, spec-auditor, agent-prompt-engineering, and optimize-prompt-loop
- Added scoring, adversarial audit, and structured output for any plan or idea
