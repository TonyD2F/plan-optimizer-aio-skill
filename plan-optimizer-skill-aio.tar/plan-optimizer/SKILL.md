---
name: plan-optimizer
description: "Optimizes any plan, idea, strategy, design, or prompt into a clear, actionable, stress-tested version. Use when the user shares a vague idea, rough plan, feature request, agent instruction, business strategy, research direction, or any concept that needs refinement, critique, or improvement — even if it is not a prompt."
type: workflow
lifecycle: active
---

# Plan Optimizer — Turn Any Idea into a Stress-Tested Plan

Transforms vague ideas, rough plans, prompts, strategies, or designs into clear, actionable, adversarially reviewed versions. Works on anything: product features, research directions, business plans, agent instructions, project roadmaps, or one-off prompts.

## When to Use

Activate on any of these signals:
- User shares a plan, idea, concept, or strategy and wants it improved
- "Optimize this plan", "improve this idea", "critique this approach", "make this better"
- Vague feature request, research direction, or agent instruction that needs structure
- Existing plan that should be stress-tested before execution

Do **not** activate for pure code implementation, debugging, or requests that already have a fully specified, approved plan.

## Core Workflow

Follow these steps in order. Adapt depth to the input size and stakes.

### 1. Classify and Score

Identify what was shared:
- **Idea** — loose concept, no structure
- **Plan** — has steps or structure but gaps
- **Prompt** — instruction for an LLM/agent
- **Strategy / Design** — higher-level approach

Score the input 1–10 on these dimensions and report them:

| Dimension | What to score |
|-----------|---------------|
| Clarity | Is the goal unambiguous? |
| Specificity | Are requirements concrete? |
| Completeness | Are what / why / how / success criteria present? |
| Actionability | Can someone (or an agent) start executing without guessing? |
| Risk awareness | Are constraints, non-goals, and failure modes named? |

### 2. Extract Intent (Grill)

Ask the minimum questions needed to close critical gaps. Prefer one sharp question at a time. Cover:
- What success looks like
- Who/what is this for
- Key constraints and non-goals
- Why now / why this approach
- What would make this a failure even if technically complete

If the input is already detailed, skip to scoring gaps only and ask about the biggest open branch.

### 3. Generate Approaches

Once intent is clear, present 2–3 real alternatives (including the user's original if viable). For each:
- Core approach
- Main trade-offs
- When it is better / worse

Recommend one and say why. Wait for the user to pick (or accept the recommendation) before proceeding.

### 4. Adversarial Audit

Stress-test the chosen approach for agent- or human-execution failure modes:
- Contradictions
- Vague or untestable acceptance criteria
- Missing edge cases
- Scope that is too large or mixed
- Assumptions that will cause wrong implementation
- Irreversible or high-risk actions without gates

Produce findings with: severity, evidence, why it breaks execution, and a recommended patch.

### 5. Deliver Optimized Version

Output in this order:

1. **Analysis** — scores, framework/approach chosen, key changes and why
2. **Optimized artifact** — the improved plan / idea / prompt, ready to use
3. **Open questions** — any remaining decisions the user must make
4. **Next step** — what to do with the result (implement, further grill, ticket, etc.)

For prompts, structure the output so it can be copied directly. For plans, use clear sections: Goal, Success criteria, Approach, Steps, Constraints / Non-goals, Verification, Risks.

## Output Template

```markdown
## Analysis
- Type: [Idea / Plan / Prompt / Strategy]
- Scores: Clarity X/10 · Specificity X/10 · Completeness X/10 · Actionability X/10 · Risk awareness X/10
- Chosen approach: [name]
- Key changes: [bullet list]

## Optimized [Plan / Prompt / Idea]

[Clean, ready-to-use version here]

## Open Questions
- [ ] ...

## Recommended Next Step
[One concrete action]
```

## Heuristics

- Prefer existing structure over inventing new process when the input is already decent.
- Never invent facts about the user's domain, metrics, users, or constraints. Use `[you fill this in: ...]` placeholders.
- For agent-facing plans, include explicit verification steps and stopping conditions.
- Keep the optimized version shorter and denser than the input unless the input was incomplete.
- If the user only wants a quick critique, stop after the adversarial audit and skip full rewrite.

## References

- Detailed scoring rubric and framework selection → `references/scoring-and-frameworks.md`
- Adversarial audit checklist → `references/audit-checklist.md`
- Output examples → `references/examples.md`
